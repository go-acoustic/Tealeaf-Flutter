// Copyright 2018 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// @dart = 2.8

import 'dart:io' as io;

import 'package:crypto/crypto.dart';
import 'package:yaml/yaml.dart';
import 'package:package_config/package_config.dart';

import 'artifacts.dart';
import 'base/common.dart';
import 'base/file_system.dart';
import 'build_info.dart';
import 'build_system/build_system.dart';
import 'build_system/targets/common.dart';
import 'cache.dart';
import 'compile.dart';
import 'dart/package_map.dart';
import 'globals.dart' as globals;

const String frontendServerDartSnapshot = 'frontend_server.dart.snapshot';
const String tealeaf_aop_path = 'tealeaf_aop';
const String globalPackagesPath = '.packages';
const String dependencies = 'dependencies';
const String aspectdPlugin = 'tl_flutter_plugin';
const String originalExt = '.original';
 
class AopLogger {
  static bool enableDebug = false;
  static bool enablePrint = true;
  static String logFile   = 'tl_flutter.log';
  static io.File file;

  // Simple debug statements (development only)
  static void d(String msg) {
    if (enableDebug) {
      if (file == null) {
        final Directory currentDirectory = globals.fs.currentDirectory;
        if (currentDirectory == null) {
            return;
        }
        file = io.File(globals.fs.path.join(currentDirectory.absolute.path, logFile));
        if (!file.existsSync()) {
          file.createSync();
        }
      }
      file.writeAsStringSync('$msg\n', mode: FileMode.append, flush: true);
    }
  }

  // Console messages indicating AOP instrumentation enabled/disabled
  static void p(String msg) {
    if (enablePrint) {
      print(msg);
    }
  }
}

class AspectdHook {
  static String dependencies  = 'dependencies';
  static String aspectdPlugin = 'tl_flutter_plugin';
  static String originalExt   = '.original';

  static bool hasAspectdPlugin() {
    final Directory pubspecDirectory = globals.fs.currentDirectory;
    
    if (pubspecDirectory.existsSync()) {
      final pubspecFilePath = globals.fs.path.join(
        pubspecDirectory.absolute.path,
        'pubspec.yaml'
      );
      final dynamic pubspecFile = globals.fs.file(pubspecFilePath);

      if (!pubspecFile.existsSync()) {
        AopLogger.d('File does not exist: $pubspecFilePath');
        return false;
      }
      final String  yamlData = pubspecFile.readAsStringSync();
      final dynamic yamlInfo = loadYaml(yamlData);

      if (yamlInfo == null) {
        AopLogger.d("Unable to parse pubspec.yaml");
        return false;
      }

      if (yamlInfo[dependencies] is! YamlMap) {
        AopLogger.d("Can not find dependencies in pubspec.yaml!");
        return false;
      }

      final YamlMap yamlMap = yamlInfo[dependencies] as YamlMap;

      if (yamlMap.containsKey(aspectdPlugin)) {
        AopLogger.p('Tealeaf AOP Instrumentation enabled');
        AopLogger.d('Found Tealeaf Instrumentation plugin at: ${pubspecFilePath}');
        return true;
      }
      AopLogger.p('No Tealeaf plugin - AOP disabled');
      AopLogger.d('No Tealeaf plugin');
    }
    else {
      AopLogger.d('Project directory does not exist!');
    }

    return false;
  }

  static Future<Directory> getProjectDirectory() async {
    final Directory currentDirectory = globals.fs.currentDirectory;
    if (currentDirectory == null) {
      return;
    }
    final String packagesPath = globals.fs.path.join(
      currentDirectory.absolute.path, 
      globalPackagesPath
    );
    return await getPackagePathFromConfig(packagesPath, aspectdPlugin);
  }

  static Future<Directory> getPackagePathFromConfig(
      String packageConfigPath, String packageName) async {
    final PackageConfig packageConfig = await loadPackageConfigWithLogging(
      globals.fs.file(packageConfigPath),
      logger: globals.logger,
    );
    if ((packageConfig?.packages?.length ?? 0) > 0) {
      final Package aspectdPackage = packageConfig.packages.toList().firstWhere(
          (Package element) => element.name == packageName,
          orElse: () => null);

      if(aspectdPackage == null) {
        return null;
      }
      return globals.fs.directory(aspectdPackage.root.toFilePath());
    }
    return null;
  }

  static Future<Directory> getAspectdFrontendServerDirectory(String packagesPath) async {
    final Directory directory = await getPackagePathFromConfig(packagesPath, aspectdPlugin);
    if (directory == null) {
      return null;
    }
    Directory aspectdFrontendServerDirectory = globals.fs.directory(globals.fs.path.join(
      directory.absolute.path, 
      tealeaf_aop_path,
      'flutter_frontend_server')
    );

    return aspectdFrontendServerDirectory;
  }

  static Future<void> enableAspectd() async {
    final Directory currentDirectory = globals.fs.currentDirectory;
    final String packagesPath = globals.fs.path
        .join(currentDirectory.absolute.path, globalPackagesPath);

    AopLogger.d('packagesPath: $packagesPath');

    final Directory tlAspectdFrontendServerDirectory =
        await getAspectdFrontendServerDirectory(packagesPath);

    final bool usingAspectd = (tlAspectdFrontendServerDirectory != null) ? hasAspectdPlugin() : false;
    
    AopLogger.d('tlAspectdFrontendServerDirectory: ' +
      '${usingAspectd ? tlAspectdFrontendServerDirectory.absolute.path : "*NOT FOUND*"}');

    final String flutterFrontendServerSnapshotPath = globals.artifacts
      .getArtifactPath(Artifact.frontendServerSnapshotForEngineDartSdk
    );
    final File flutterServerFile = globals.fs.file(flutterFrontendServerSnapshotPath);
    final String snapshotBackupPath = flutterFrontendServerSnapshotPath + originalExt;
    final File backupFile = globals.fs.file(snapshotBackupPath);

    if (usingAspectd) { 
      final String aspectdFrontendServerSnapshotPath = globals.fs.path.join(
        tlAspectdFrontendServerDirectory.absolute.path,
        frontendServerDartSnapshot,
      );
      final File aspectdServerFile = globals.fs.file(aspectdFrontendServerSnapshotPath);

      if (!aspectdServerFile.existsSync()) {
        AopLogger.p('Aspectd frontend service not available, AOP disabled!');
        return;
      }
      if (!backupFile.existsSync()) {
        AopLogger.d('Backing up frontend server to: $snapshotBackupPath');
        flutterServerFile.renameSync(snapshotBackupPath);    
      } 
      else if (flutterServerFile.existsSync()) {
        if (md5.convert(flutterServerFile.readAsBytesSync()) == 
            md5.convert(aspectdServerFile.readAsBytesSync())) {
          return;
        }
      }
      AopLogger.p('Updated frontend server for Tealeaf AOP: $aspectdFrontendServerSnapshotPath');

      aspectdServerFile.copySync(flutterFrontendServerSnapshotPath);
    }
    else {
      if (backupFile.existsSync()) {
        if (flutterServerFile.existsSync()) {
          flutterServerFile.deleteSync();
        }
        AopLogger.p('Reverted frontend server to original version');
        backupFile.renameSync(flutterFrontendServerSnapshotPath);
      } 
    }
  }
}
